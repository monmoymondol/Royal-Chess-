import { PieceColor } from '@/lib/chessTypes';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface GameStatusProps {
  currentPlayer: PieceColor;
  gameStatus: 'playing' | 'check' | 'checkmate' | 'stalemate';
  onReset: () => void;
}

export default function GameStatus({ currentPlayer, gameStatus, onReset }: GameStatusProps) {
  const getStatusMessage = () => {
    switch (gameStatus) {
      case 'check':
        return `${currentPlayer === 'white' ? 'White' : 'Black'} is in check!`;
      case 'checkmate':
        return `Checkmate! ${currentPlayer === 'white' ? 'Black' : 'White'} wins!`;
      case 'stalemate':
        return 'Stalemate! The game is a draw.';
      default:
        return `${currentPlayer === 'white' ? 'White' : 'Black'}'s turn`;
    }
  };

  const getStatusColor = () => {
    switch (gameStatus) {
      case 'check':
        return 'text-yellow-600';
      case 'checkmate':
        return 'text-red-600';
      case 'stalemate':
        return 'text-blue-600';
      default:
        return 'text-gray-700';
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-center">Chess Game</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className={`text-center font-semibold text-lg ${getStatusColor()}`}>
          {getStatusMessage()}
        </div>
        
        <div className="flex justify-center">
          <Button onClick={onReset} variant="outline">
            New Game
          </Button>
        </div>
        
        <div className="text-sm text-gray-500 text-center">
          Click a piece to select it, then click a valid square to move.
        </div>
      </CardContent>
    </Card>
  );
}