import { Board, ChessPiece, Position, PieceColor, Move, GameState } from './chessTypes';
import { isValidPosition, copyBoard, isSamePosition } from './chessUtils';

export function getValidMoves(gameState: GameState, from: Position): Position[] {
  const { board, canCastleKingside, canCastleQueenside, enPassantTarget } = gameState;
  const piece = board[from.row][from.col];
  if (!piece) return [];

  const moves: Position[] = [];
  
  switch (piece.type) {
    case 'pawn':
      moves.push(...getPawnMoves(board, from, piece.color, enPassantTarget));
      break;
    case 'rook':
      moves.push(...getRookMoves(board, from, piece.color));
      break;
    case 'bishop':
      moves.push(...getBishopMoves(board, from, piece.color));
      break;
    case 'queen':
      moves.push(...getQueenMoves(board, from, piece.color));
      break;
    case 'king':
      moves.push(...getKingMoves(board, from, piece.color, canCastleKingside, canCastleQueenside));
      break;
    case 'knight':
      moves.push(...getKnightMoves(board, from, piece.color));
      break;
  }

  // Filter out moves that would put own king in check
  return moves.filter(to => !wouldBeInCheck(board, from, to, piece.color));
}

function getPawnMoves(board: Board, from: Position, color: PieceColor, enPassantTarget: Position | null): Position[] {
  const moves: Position[] = [];
  const direction = color === 'white' ? -1 : 1;
  const startRow = color === 'white' ? 6 : 1;

  // Forward move
  const oneStep = { row: from.row + direction, col: from.col };
  if (isValidPosition(oneStep) && !board[oneStep.row][oneStep.col]) {
    moves.push(oneStep);
    
    // Two steps from starting position
    if (from.row === startRow) {
      const twoSteps = { row: from.row + 2 * direction, col: from.col };
      if (isValidPosition(twoSteps) && !board[twoSteps.row][twoSteps.col]) {
        moves.push(twoSteps);
      }
    }
  }

  // Diagonal captures
  for (const colOffset of [-1, 1]) {
    const capturePos = { row: from.row + direction, col: from.col + colOffset };
    if (isValidPosition(capturePos)) {
      const targetPiece = board[capturePos.row][capturePos.col];
      if (targetPiece && targetPiece.color !== color) {
        moves.push(capturePos);
      }
      // En passant
      else if (enPassantTarget && isSamePosition(capturePos, enPassantTarget)) {
        moves.push(capturePos);
      }
    }
  }

  return moves;
}

function getRookMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const directions = [[0, 1], [0, -1], [1, 0], [-1, 0]];

  for (const [dRow, dCol] of directions) {
    for (let i = 1; i < 8; i++) {
      const pos = { row: from.row + i * dRow, col: from.col + i * dCol };
      if (!isValidPosition(pos)) break;

      const piece = board[pos.row][pos.col];
      if (!piece) {
        moves.push(pos);
      } else {
        if (piece.color !== color) {
          moves.push(pos);
        }
        break;
      }
    }
  }

  return moves;
}

function getBishopMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const directions = [[1, 1], [1, -1], [-1, 1], [-1, -1]];

  for (const [dRow, dCol] of directions) {
    for (let i = 1; i < 8; i++) {
      const pos = { row: from.row + i * dRow, col: from.col + i * dCol };
      if (!isValidPosition(pos)) break;

      const piece = board[pos.row][pos.col];
      if (!piece) {
        moves.push(pos);
      } else {
        if (piece.color !== color) {
          moves.push(pos);
        }
        break;
      }
    }
  }

  return moves;
}

function getQueenMoves(board: Board, from: Position, color: PieceColor): Position[] {
  return [...getRookMoves(board, from, color), ...getBishopMoves(board, from, color)];
}

function getKingMoves(board: Board, from: Position, color: PieceColor, canCastleKingside: { white: boolean; black: boolean }, canCastleQueenside: { white: boolean; black: boolean }): Position[] {
  const moves: Position[] = [];
  const directions = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1],  [1, 0],  [1, 1]
  ];

  // Regular king moves
  for (const [dRow, dCol] of directions) {
    const pos = { row: from.row + dRow, col: from.col + dCol };
    if (isValidPosition(pos)) {
      const piece = board[pos.row][pos.col];
      if (!piece || piece.color !== color) {
        moves.push(pos);
      }
    }
  }

  // Castling moves
  const kingRow = color === 'white' ? 7 : 0;
  if (from.row === kingRow && from.col === 4) {
    // Kingside castling
    if (canCastleKingside[color]) {
      if (!board[kingRow][5] && !board[kingRow][6] && board[kingRow][7]?.type === 'rook') {
        if (!isSquareAttacked(board, { row: kingRow, col: 4 }, color === 'white' ? 'black' : 'white') &&
            !isSquareAttacked(board, { row: kingRow, col: 5 }, color === 'white' ? 'black' : 'white') &&
            !isSquareAttacked(board, { row: kingRow, col: 6 }, color === 'white' ? 'black' : 'white')) {
          moves.push({ row: kingRow, col: 6 });
        }
      }
    }

    // Queenside castling
    if (canCastleQueenside[color]) {
      if (!board[kingRow][3] && !board[kingRow][2] && !board[kingRow][1] && board[kingRow][0]?.type === 'rook') {
        if (!isSquareAttacked(board, { row: kingRow, col: 4 }, color === 'white' ? 'black' : 'white') &&
            !isSquareAttacked(board, { row: kingRow, col: 3 }, color === 'white' ? 'black' : 'white') &&
            !isSquareAttacked(board, { row: kingRow, col: 2 }, color === 'white' ? 'black' : 'white')) {
          moves.push({ row: kingRow, col: 2 });
        }
      }
    }
  }

  return moves;
}

function getKnightMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const knightMoves = [
    [-2, -1], [-2, 1], [-1, -2], [-1, 2],
    [1, -2], [1, 2], [2, -1], [2, 1]
  ];

  for (const [dRow, dCol] of knightMoves) {
    const pos = { row: from.row + dRow, col: from.col + dCol };
    if (isValidPosition(pos)) {
      const piece = board[pos.row][pos.col];
      if (!piece || piece.color !== color) {
        moves.push(pos);
      }
    }
  }

  return moves;
}

function findKing(board: Board, color: PieceColor): Position | null {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.type === 'king' && piece.color === color) {
        return { row, col };
      }
    }
  }
  return null;
}

function isSquareAttacked(board: Board, pos: Position, byColor: PieceColor): boolean {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === byColor) {
        const moves = getValidMovesWithoutCheckValidation(board, { row, col });
        if (moves.some(move => isSamePosition(move, pos))) {
          return true;
        }
      }
    }
  }
  return false;
}

function getValidMovesWithoutCheckValidation(board: Board, from: Position): Position[] {
  const piece = board[from.row][from.col];
  if (!piece) return [];

  switch (piece.type) {
    case 'pawn':
      return getPawnMoves(board, from, piece.color, null);
    case 'rook':
      return getRookMoves(board, from, piece.color);
    case 'bishop':
      return getBishopMoves(board, from, piece.color);
    case 'queen':
      return getQueenMoves(board, from, piece.color);
    case 'king':
      return getKingMoves(board, from, piece.color, { white: false, black: false }, { white: false, black: false });
    case 'knight':
      return getKnightMoves(board, from, piece.color);
    default:
      return [];
  }
}

function wouldBeInCheck(board: Board, from: Position, to: Position, color: PieceColor): boolean {
  const newBoard = copyBoard(board);
  newBoard[to.row][to.col] = newBoard[from.row][from.col];
  newBoard[from.row][from.col] = null;

  const kingPos = findKing(newBoard, color);
  if (!kingPos) return false;

  return isSquareAttacked(newBoard, kingPos, color === 'white' ? 'black' : 'white');
}

export function isInCheck(board: Board, color: PieceColor): boolean {
  const kingPos = findKing(board, color);
  if (!kingPos) return false;

  return isSquareAttacked(board, kingPos, color === 'white' ? 'black' : 'white');
}

export function isCheckmate(board: Board, color: PieceColor): boolean {
  if (!isInCheck(board, color)) return false;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === color) {
        const gameState = {
          board,
          currentPlayer: color,
          selectedSquare: null,
          validMoves: [],
          gameStatus: 'playing' as const,
          moveHistory: [],
          canCastleKingside: { white: true, black: true },
          canCastleQueenside: { white: true, black: true },
          enPassantTarget: null
        };
        const moves = getValidMoves(gameState, { row, col });
        if (moves.length > 0) return false;
      }
    }
  }

  return true;
}

export function makeMove(gameState: GameState, from: Position, to: Position): GameState {
  const newBoard = copyBoard(gameState.board);
  const piece = newBoard[from.row][from.col];
  const capturedPiece = newBoard[to.row][to.col];
  
  // Handle castling
  const isCastling = piece?.type === 'king' && Math.abs(to.col - from.col) === 2;
  if (isCastling) {
    // Move rook for castling
    if (to.col === 6) { // Kingside
      const rook = newBoard[from.row][7];
      newBoard[from.row][5] = rook;
      newBoard[from.row][7] = null;
      if (rook) rook.hasMoved = true;
    } else if (to.col === 2) { // Queenside
      const rook = newBoard[from.row][0];
      newBoard[from.row][3] = rook;
      newBoard[from.row][0] = null;
      if (rook) rook.hasMoved = true;
    }
  }

  // Handle en passant
  const isEnPassant = piece?.type === 'pawn' && 
                      gameState.enPassantTarget && 
                      isSamePosition(to, gameState.enPassantTarget);
  if (isEnPassant) {
    const capturedPawnRow = piece.color === 'white' ? to.row + 1 : to.row - 1;
    newBoard[capturedPawnRow][to.col] = null;
  }

  // Make the move
  newBoard[to.row][to.col] = piece;
  newBoard[from.row][from.col] = null;
  if (piece) piece.hasMoved = true;

  // Update castling rights
  const newCanCastleKingside = { ...gameState.canCastleKingside };
  const newCanCastleQueenside = { ...gameState.canCastleQueenside };

  if (piece?.type === 'king') {
    newCanCastleKingside[piece.color] = false;
    newCanCastleQueenside[piece.color] = false;
  } else if (piece?.type === 'rook') {
    if (from.col === 0) newCanCastleQueenside[piece.color] = false;
    if (from.col === 7) newCanCastleKingside[piece.color] = false;
  }

  // Update en passant target
  let newEnPassantTarget: Position | null = null;
  if (piece?.type === 'pawn' && Math.abs(to.row - from.row) === 2) {
    newEnPassantTarget = { row: (from.row + to.row) / 2, col: from.col };
  }

  const nextPlayer: PieceColor = gameState.currentPlayer === 'white' ? 'black' : 'white';
  
  let newGameStatus: GameState['gameStatus'] = 'playing';
  if (isInCheck(newBoard, nextPlayer)) {
    newGameStatus = isCheckmate(newBoard, nextPlayer) ? 'checkmate' : 'check';
  }

  return {
    ...gameState,
    board: newBoard,
    currentPlayer: nextPlayer,
    selectedSquare: null,
    validMoves: [],
    gameStatus: newGameStatus,
    canCastleKingside: newCanCastleKingside,
    canCastleQueenside: newCanCastleQueenside,
    enPassantTarget: newEnPassantTarget,
    moveHistory: [...gameState.moveHistory, {
      from,
      to,
      piece: piece!,
      capturedPiece,
      isCastling,
      isEnPassant
    }]
  };
}