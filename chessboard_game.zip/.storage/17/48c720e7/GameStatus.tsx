import { PieceColor } from '@/lib/chessTypes';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RotateCcw, Crown, AlertTriangle } from 'lucide-react';

interface GameStatusProps {
  currentPlayer: PieceColor;
  gameStatus: 'playing' | 'check' | 'checkmate' | 'stalemate';
  onReset: () => void;
}

export default function GameStatus({ currentPlayer, gameStatus, onReset }: GameStatusProps) {
  const getStatusMessage = () => {
    switch (gameStatus) {
      case 'check':
        return `${currentPlayer === 'white' ? 'White' : 'Black'} is in check!`;
      case 'checkmate':
        return `Checkmate! ${currentPlayer === 'white' ? 'Black' : 'White'} wins!`;
      case 'stalemate':
        return 'Stalemate! The game is a draw.';
      default:
        return `${currentPlayer === 'white' ? 'White' : 'Black'}'s turn`;
    }
  };

  const getStatusIcon = () => {
    switch (gameStatus) {
      case 'check':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'checkmate':
        return <Crown className="w-5 h-5 text-red-500" />;
      case 'stalemate':
        return <Crown className="w-5 h-5 text-blue-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = () => {
    switch (gameStatus) {
      case 'check':
        return <Badge variant="destructive" className="animate-pulse">CHECK</Badge>;
      case 'checkmate':
        return <Badge variant="destructive">CHECKMATE</Badge>;
      case 'stalemate':
        return <Badge variant="secondary">STALEMATE</Badge>;
      default:
        return (
          <Badge 
            variant={currentPlayer === 'white' ? 'default' : 'secondary'}
            className="bg-gradient-to-r from-amber-500 to-amber-600 text-white"
          >
            {currentPlayer === 'white' ? 'WHITE' : 'BLACK'} TO MOVE
          </Badge>
        );
    }
  };

  return (
    <Card className="w-full max-w-md bg-gradient-to-br from-slate-50 to-slate-100 border-2 border-amber-200 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-t-lg">
        <CardTitle className="text-center flex items-center justify-center gap-2 text-xl">
          <Crown className="w-6 h-6" />
          Chess Game
          <Crown className="w-6 h-6" />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="text-center space-y-3">
          <div className="flex items-center justify-center gap-2">
            {getStatusIcon()}
            <span className="font-bold text-lg text-gray-800">
              {getStatusMessage()}
            </span>
          </div>
          
          <div className="flex justify-center">
            {getStatusBadge()}
          </div>
        </div>
        
        <div className="flex justify-center">
          <Button 
            onClick={onReset} 
            variant="outline"
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border-amber-400 hover:border-amber-500 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            New Game
          </Button>
        </div>
        
        <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
          <div className="text-sm text-gray-600 space-y-1">
            <p className="font-semibold text-amber-800">How to play:</p>
            <p>• Click a piece to select it</p>
            <p>• Click highlighted squares to move</p>
            <p>• Drag & drop pieces to move</p>
            <p>• Pawns promote when reaching the end</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}