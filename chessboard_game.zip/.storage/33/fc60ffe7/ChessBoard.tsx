import { useState, useCallback } from 'react';
import { Board, Position, GameState, PieceColor, PieceType, ChessPiece } from '@/lib/chessTypes';
import { getSquareColor, isSamePosition } from '@/lib/chessUtils';
import { getValidMoves, isInCheck, isCheckmate, makeMove } from '@/lib/chessLogic';
import ChessPieceComponent from './ChessPiece';
import PawnPromotionDialog from './PawnPromotionDialog';

interface ChessBoardProps {
  gameState: GameState;
  onGameStateChange: (gameState: GameState) => void;
}

export default function ChessBoard({ gameState, onGameStateChange }: ChessBoardProps) {
  const [draggedPiece, setDraggedPiece] = useState<Position | null>(null);
  const [promotionState, setPromotionState] = useState<{
    isOpen: boolean;
    from: Position | null;
    to: Position | null;
    color: PieceColor;
  }>({
    isOpen: false,
    from: null,
    to: null,
    color: 'white'
  });

  const isPawnPromotion = (from: Position, to: Position, piece: ChessPiece | null) => {
    if (piece?.type !== 'pawn') return false;
    return (piece.color === 'white' && to.row === 0) || (piece.color === 'black' && to.row === 7);
  };

  const handlePromotion = (pieceType: PieceType) => {
    if (!promotionState.from || !promotionState.to) return;

    let newGameState = makeMove(gameState, promotionState.from, promotionState.to);
    newGameState.board[promotionState.to.row][promotionState.to.col] = {
      type: pieceType,
      color: promotionState.color,
      hasMoved: true
    };

    // Recheck game status after promotion
    const nextPlayer = newGameState.currentPlayer;
    if (isInCheck(newGameState.board, nextPlayer)) {
      newGameState.gameStatus = isCheckmate(newGameState.board, nextPlayer) ? 'checkmate' : 'check';
    }

    onGameStateChange(newGameState);
    setPromotionState({ isOpen: false, from: null, to: null, color: 'white' });
  };

  const handleSquareClick = useCallback((row: number, col: number) => {
    const clickedPos = { row, col };
    const piece = gameState.board[row][col];

    if (!gameState.selectedSquare) {
      if (piece && piece.color === gameState.currentPlayer) {
        const validMoves = getValidMoves(gameState, clickedPos);
        onGameStateChange({
          ...gameState,
          selectedSquare: clickedPos,
          validMoves
        });
      }
      return;
    }

    if (isSamePosition(gameState.selectedSquare, clickedPos)) {
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
      return;
    }

    if (piece && piece.color === gameState.currentPlayer) {
      const validMoves = getValidMoves(gameState, clickedPos);
      onGameStateChange({
        ...gameState,
        selectedSquare: clickedPos,
        validMoves
      });
      return;
    }

    const isValidMove = gameState.validMoves.some(move => 
      isSamePosition(move, clickedPos)
    );

    if (isValidMove) {
      const selectedPiece = gameState.board[gameState.selectedSquare.row][gameState.selectedSquare.col];
      
      // Check for pawn promotion
      if (isPawnPromotion(gameState.selectedSquare, clickedPos, selectedPiece)) {
        setPromotionState({
          isOpen: true,
          from: gameState.selectedSquare,
          to: clickedPos,
          color: selectedPiece!.color
        });
        return;
      }

      // Make the move
      const newGameState = makeMove(gameState, gameState.selectedSquare, clickedPos);
      onGameStateChange(newGameState);
    } else {
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragStart = useCallback((row: number, col: number) => {
    const piece = gameState.board[row][col];
    if (piece && piece.color === gameState.currentPlayer) {
      setDraggedPiece({ row, col });
      const validMoves = getValidMoves(gameState, { row, col });
      onGameStateChange({
        ...gameState,
        selectedSquare: { row, col },
        validMoves
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, row: number, col: number) => {
    e.preventDefault();
    if (draggedPiece) {
      handleSquareClick(row, col);
      setDraggedPiece(null);
    }
  }, [draggedPiece, handleSquareClick]);

  const isSquareSelected = (row: number, col: number) => {
    return gameState.selectedSquare && 
           isSamePosition(gameState.selectedSquare, { row, col });
  };

  const isValidMoveSquare = (row: number, col: number) => {
    return gameState.validMoves.some(move => 
      isSamePosition(move, { row, col })
    );
  };

  const isCastlingMove = (row: number, col: number) => {
    if (!gameState.selectedSquare) return false;
    const piece = gameState.board[gameState.selectedSquare.row][gameState.selectedSquare.col];
    return piece?.type === 'king' && Math.abs(col - gameState.selectedSquare.col) === 2;
  };

  const getSquareStyle = (rowIndex: number, colIndex: number) => {
    const squareColor = getSquareColor(rowIndex, colIndex);
    const isSelected = isSquareSelected(rowIndex, colIndex);
    const isValidMove = isValidMoveSquare(rowIndex, colIndex);
    const isCastling = isCastlingMove(rowIndex, colIndex);
    
    let baseClasses = `
      w-24 h-24 flex items-center justify-center relative cursor-pointer
      transition-all duration-500 transform-gpu
      hover:scale-110 hover:z-10 hover:rotate-1
      border-2 border-opacity-30
    `;
    
    if (squareColor === 'light') {
      baseClasses += ` bg-gradient-to-br from-amber-50 via-yellow-100 to-amber-200
        shadow-inner border-amber-300
        hover:from-amber-100 hover:to-amber-300`;
    } else {
      baseClasses += ` bg-gradient-to-br from-amber-900 via-amber-800 to-amber-700
        shadow-inner border-amber-600
        hover:from-amber-800 hover:to-amber-600`;
    }
    
    if (isSelected) {
      baseClasses += ` ring-4 ring-blue-400 ring-opacity-90 shadow-2xl scale-110 z-20
        animate-pulse bg-gradient-to-br from-blue-200 to-blue-300`;
    }
    
    if (isValidMove) {
      if (isCastling) {
        baseClasses += ` ring-4 ring-purple-500 ring-opacity-90 shadow-purple-300 shadow-2xl
          bg-gradient-to-br from-purple-200 to-purple-400 animate-bounce`;
      } else {
        baseClasses += ` ring-3 ring-emerald-400 ring-opacity-90 shadow-emerald-300 shadow-xl
          bg-gradient-to-br from-emerald-200 to-emerald-300`;
      }
    }
    
    return baseClasses;
  };

  return (
    <>
      <div className="relative">
        {/* Royal decorative frame */}
        <div className="absolute -inset-8 bg-gradient-to-br from-amber-900 via-yellow-700 to-amber-800 rounded-3xl shadow-2xl">
          <div className="absolute inset-2 bg-gradient-to-br from-amber-700 to-amber-900 rounded-2xl">
            <div className="absolute inset-1 border-4 border-yellow-400 rounded-xl opacity-60"></div>
            <div className="absolute top-4 left-4 w-8 h-8 bg-yellow-400 rounded-full shadow-lg"></div>
            <div className="absolute top-4 right-4 w-8 h-8 bg-yellow-400 rounded-full shadow-lg"></div>
            <div className="absolute bottom-4 left-4 w-8 h-8 bg-yellow-400 rounded-full shadow-lg"></div>
            <div className="absolute bottom-4 right-4 w-8 h-8 bg-yellow-400 rounded-full shadow-lg"></div>
          </div>
        </div>

        {/* Main chess board */}
        <div className="relative border-8 border-gradient-to-br from-amber-900 to-amber-700 rounded-2xl shadow-2xl bg-gradient-to-br from-amber-800 to-amber-900 p-4">
          <div className="border-4 border-amber-600 rounded-lg overflow-hidden shadow-inner bg-gradient-to-br from-amber-100 to-amber-200">
            {gameState.board.map((row, rowIndex) => (
              <div key={rowIndex} className="flex">
                {row.map((piece, colIndex) => {
                  const isValidMove = isValidMoveSquare(rowIndex, colIndex);
                  const isDragging = draggedPiece && 
                                   isSamePosition(draggedPiece, { row: rowIndex, col: colIndex });
                  const isCastling = isCastlingMove(rowIndex, colIndex);

                  return (
                    <div
                      key={`${rowIndex}-${colIndex}`}
                      className={getSquareStyle(rowIndex, colIndex)}
                      onClick={() => handleSquareClick(rowIndex, colIndex)}
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, rowIndex, colIndex)}
                      style={{
                        boxShadow: isValidMove 
                          ? isCastling
                            ? 'inset 0 0 30px rgba(147, 51, 234, 0.4), 0 0 30px rgba(147, 51, 234, 0.3)'
                            : 'inset 0 0 25px rgba(34, 197, 94, 0.4), 0 0 25px rgba(34, 197, 94, 0.3)'
                          : 'inset 0 4px 8px rgba(0,0,0,0.15), 0 2px 4px rgba(0,0,0,0.1)'
                      }}
                    >
                      {piece && (
                        <ChessPieceComponent
                          piece={piece}
                          onDragStart={() => handleDragStart(rowIndex, colIndex)}
                          isDragging={isDragging}
                        />
                      )}
                      {isValidMove && !piece && (
                        <div className={`w-8 h-8 rounded-full opacity-90 shadow-xl animate-pulse
                          ${isCastling 
                            ? 'bg-purple-500 ring-2 ring-purple-300' 
                            : 'bg-emerald-500 ring-2 ring-emerald-300'
                          }`} 
                        />
                      )}
                      {isValidMove && piece && (
                        <div className={`absolute inset-2 border-4 rounded-lg opacity-80 animate-pulse
                          ${isCastling 
                            ? 'border-purple-500 shadow-purple-400' 
                            : 'border-emerald-500 shadow-emerald-400'
                          }`} 
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          
          {/* Enhanced board coordinates */}
          <div className="flex justify-between mt-4 px-4">
            {['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((letter) => (
              <div key={letter} className="w-24 text-center text-yellow-200 font-bold text-lg tracking-wider drop-shadow-lg">
                {letter}
              </div>
            ))}
          </div>
          <div className="absolute left-0 top-4 bottom-4 flex flex-col justify-between items-center px-2">
            {[8, 7, 6, 5, 4, 3, 2, 1].map((number) => (
              <div key={number} className="h-24 flex items-center text-yellow-200 font-bold text-lg tracking-wider drop-shadow-lg">
                {number}
              </div>
            ))}
          </div>
        </div>
      </div>

      <PawnPromotionDialog
        isOpen={promotionState.isOpen}
        color={promotionState.color}
        onSelect={handlePromotion}
      />
    </>
  );
}