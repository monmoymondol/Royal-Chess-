import { useState, useCallback } from 'react';
import { Board, Position, GameState, PieceColor, PieceType } from '@/lib/chessTypes';
import { createInitialBoard, getSquareColor, isSamePosition } from '@/lib/chessUtils';
import { getValidMoves, isInCheck, isCheckmate, makeMove } from '@/lib/chessLogic';
import ChessPiece from './ChessPiece';
import PawnPromotionDialog from './PawnPromotionDialog';

interface ChessBoardProps {
  gameState: GameState;
  onGameStateChange: (gameState: GameState) => void;
}

export default function ChessBoard({ gameState, onGameStateChange }: ChessBoardProps) {
  const [draggedPiece, setDraggedPiece] = useState<Position | null>(null);
  const [promotionState, setPromotionState] = useState<{
    isOpen: boolean;
    from: Position | null;
    to: Position | null;
    color: PieceColor;
  }>({
    isOpen: false,
    from: null,
    to: null,
    color: 'white'
  });

  const isPawnPromotion = (from: Position, to: Position, piece: any) => {
    if (piece?.type !== 'pawn') return false;
    return (piece.color === 'white' && to.row === 0) || (piece.color === 'black' && to.row === 7);
  };

  const handlePromotion = (pieceType: PieceType) => {
    if (!promotionState.from || !promotionState.to) return;

    const newBoard = makeMove(gameState.board, promotionState.from, promotionState.to);
    newBoard[promotionState.to.row][promotionState.to.col] = {
      type: pieceType,
      color: promotionState.color
    };

    const nextPlayer: PieceColor = gameState.currentPlayer === 'white' ? 'black' : 'white';
    
    let newGameStatus: GameState['gameStatus'] = 'playing';
    if (isInCheck(newBoard, nextPlayer)) {
      newGameStatus = isCheckmate(newBoard, nextPlayer) ? 'checkmate' : 'check';
    }

    onGameStateChange({
      ...gameState,
      board: newBoard,
      currentPlayer: nextPlayer,
      selectedSquare: null,
      validMoves: [],
      gameStatus: newGameStatus
    });

    setPromotionState({ isOpen: false, from: null, to: null, color: 'white' });
  };

  const handleSquareClick = useCallback((row: number, col: number) => {
    const clickedPos = { row, col };
    const piece = gameState.board[row][col];

    if (!gameState.selectedSquare) {
      if (piece && piece.color === gameState.currentPlayer) {
        const validMoves = getValidMoves(gameState.board, clickedPos);
        onGameStateChange({
          ...gameState,
          selectedSquare: clickedPos,
          validMoves
        });
      }
      return;
    }

    if (isSamePosition(gameState.selectedSquare, clickedPos)) {
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
      return;
    }

    if (piece && piece.color === gameState.currentPlayer) {
      const validMoves = getValidMoves(gameState.board, clickedPos);
      onGameStateChange({
        ...gameState,
        selectedSquare: clickedPos,
        validMoves
      });
      return;
    }

    const isValidMove = gameState.validMoves.some(move => 
      isSamePosition(move, clickedPos)
    );

    if (isValidMove) {
      const selectedPiece = gameState.board[gameState.selectedSquare.row][gameState.selectedSquare.col];
      
      // Check for pawn promotion
      if (isPawnPromotion(gameState.selectedSquare, clickedPos, selectedPiece)) {
        setPromotionState({
          isOpen: true,
          from: gameState.selectedSquare,
          to: clickedPos,
          color: selectedPiece!.color
        });
        return;
      }

      // Regular move
      const newBoard = makeMove(gameState.board, gameState.selectedSquare, clickedPos);
      const nextPlayer: PieceColor = gameState.currentPlayer === 'white' ? 'black' : 'white';
      
      let newGameStatus: GameState['gameStatus'] = 'playing';
      if (isInCheck(newBoard, nextPlayer)) {
        newGameStatus = isCheckmate(newBoard, nextPlayer) ? 'checkmate' : 'check';
      }

      onGameStateChange({
        ...gameState,
        board: newBoard,
        currentPlayer: nextPlayer,
        selectedSquare: null,
        validMoves: [],
        gameStatus: newGameStatus
      });
    } else {
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragStart = useCallback((row: number, col: number) => {
    const piece = gameState.board[row][col];
    if (piece && piece.color === gameState.currentPlayer) {
      setDraggedPiece({ row, col });
      const validMoves = getValidMoves(gameState.board, { row, col });
      onGameStateChange({
        ...gameState,
        selectedSquare: { row, col },
        validMoves
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, row: number, col: number) => {
    e.preventDefault();
    if (draggedPiece) {
      handleSquareClick(row, col);
      setDraggedPiece(null);
    }
  }, [draggedPiece, handleSquareClick]);

  const isSquareSelected = (row: number, col: number) => {
    return gameState.selectedSquare && 
           isSamePosition(gameState.selectedSquare, { row, col });
  };

  const isValidMoveSquare = (row: number, col: number) => {
    return gameState.validMoves.some(move => 
      isSamePosition(move, { row, col })
    );
  };

  const getSquareStyle = (rowIndex: number, colIndex: number) => {
    const squareColor = getSquareColor(rowIndex, colIndex);
    const isSelected = isSquareSelected(rowIndex, colIndex);
    const isValidMove = isValidMoveSquare(rowIndex, colIndex);
    
    let baseClasses = `
      w-20 h-20 flex items-center justify-center relative cursor-pointer
      transition-all duration-300 transform-gpu
      hover:scale-105 hover:z-10
    `;
    
    if (squareColor === 'light') {
      baseClasses += ` bg-gradient-to-br from-amber-100 via-amber-50 to-yellow-100
        shadow-inner border border-amber-200`;
    } else {
      baseClasses += ` bg-gradient-to-br from-amber-800 via-amber-700 to-amber-900
        shadow-inner border border-amber-600`;
    }
    
    if (isSelected) {
      baseClasses += ` ring-4 ring-blue-400 ring-opacity-80 shadow-lg scale-105 z-20`;
    }
    
    if (isValidMove) {
      baseClasses += ` ring-2 ring-green-400 ring-opacity-90 shadow-green-200 shadow-lg`;
    }
    
    return baseClasses;
  };

  return (
    <>
      <div className="inline-block border-8 border-gradient-to-br from-amber-900 to-amber-700 rounded-2xl shadow-2xl bg-gradient-to-br from-amber-800 to-amber-900 p-2">
        <div className="border-4 border-amber-600 rounded-lg overflow-hidden shadow-inner">
          {gameState.board.map((row, rowIndex) => (
            <div key={rowIndex} className="flex">
              {row.map((piece, colIndex) => {
                const isValidMove = isValidMoveSquare(rowIndex, colIndex);
                const isDragging = draggedPiece && 
                                 isSamePosition(draggedPiece, { row: rowIndex, col: colIndex });

                return (
                  <div
                    key={`${rowIndex}-${colIndex}`}
                    className={getSquareStyle(rowIndex, colIndex)}
                    onClick={() => handleSquareClick(rowIndex, colIndex)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, rowIndex, colIndex)}
                    style={{
                      boxShadow: isValidMove 
                        ? 'inset 0 0 20px rgba(34, 197, 94, 0.3), 0 0 20px rgba(34, 197, 94, 0.2)'
                        : 'inset 0 2px 4px rgba(0,0,0,0.1)'
                    }}
                  >
                    {piece && (
                      <ChessPiece
                        piece={piece}
                        onDragStart={() => handleDragStart(rowIndex, colIndex)}
                        isDragging={isDragging}
                      />
                    )}
                    {isValidMove && !piece && (
                      <div className="w-6 h-6 bg-green-400 rounded-full opacity-80 shadow-lg animate-pulse" />
                    )}
                    {isValidMove && piece && (
                      <div className="absolute inset-1 border-4 border-green-400 rounded-lg opacity-70 animate-pulse" />
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        
        {/* Board coordinates */}
        <div className="flex justify-between mt-2 px-2">
          {['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((letter) => (
            <div key={letter} className="w-20 text-center text-amber-200 font-bold text-sm">
              {letter}
            </div>
          ))}
        </div>
      </div>

      <PawnPromotionDialog
        isOpen={promotionState.isOpen}
        color={promotionState.color}
        onSelect={handlePromotion}
      />
    </>
  );
}