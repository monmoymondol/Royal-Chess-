import { PieceType, PieceColor } from '@/lib/chessTypes';
import { PIECE_SYMBOLS } from '@/lib/chessUtils';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface PawnPromotionDialogProps {
  isOpen: boolean;
  color: PieceColor;
  onSelect: (pieceType: PieceType) => void;
}

export default function PawnPromotionDialog({ isOpen, color, onSelect }: PawnPromotionDialogProps) {
  const promotionPieces: PieceType[] = ['queen', 'rook', 'bishop', 'knight'];

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">
            Choose Promotion Piece
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 p-4">
          {promotionPieces.map((pieceType) => (
            <Button
              key={pieceType}
              variant="outline"
              className="h-20 text-4xl hover:scale-105 transition-all duration-200 bg-gradient-to-br from-amber-50 to-amber-100 hover:from-amber-100 hover:to-amber-200 border-2 hover:border-amber-400"
              onClick={() => onSelect(pieceType)}
            >
              <div className="flex flex-col items-center gap-2">
                <span 
                  className={`
                    ${color === 'white' 
                      ? 'text-white filter drop-shadow-[0_0_8px_rgba(0,0,0,0.8)]' 
                      : 'text-gray-900 filter drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]'
                    }
                  `}
                  style={{
                    textShadow: color === 'white' 
                      ? '2px 2px 4px rgba(0,0,0,0.8)' 
                      : '1px 1px 2px rgba(255,255,255,0.8)'
                  }}
                >
                  {PIECE_SYMBOLS[color][pieceType]}
                </span>
                <span className="text-xs capitalize font-medium">{pieceType}</span>
              </div>
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}