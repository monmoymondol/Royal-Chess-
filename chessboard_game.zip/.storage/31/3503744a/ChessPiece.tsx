import { ChessPiece as ChessPieceType } from '@/lib/chessTypes';
import { PIECE_SYMBOLS } from '@/lib/chessUtils';

interface ChessPieceProps {
  piece: ChessPieceType;
  onDragStart?: (e: React.DragEvent) => void;
  onClick?: () => void;
  isDragging?: boolean;
}

export default function ChessPiece({ piece, onDragStart, onClick, isDragging }: ChessPieceProps) {
  return (
    <div
      className={`
        text-6xl cursor-pointer select-none transition-all duration-500
        hover:scale-125 active:scale-95 hover:rotate-6
        ${isDragging ? 'opacity-50 scale-110 rotate-12' : 'opacity-100'}
        drop-shadow-2xl hover:drop-shadow-[0_0_25px_rgba(255,215,0,0.8)]
        transform-gpu
        ${piece.color === 'white' 
          ? 'text-white filter drop-shadow-[0_0_12px_rgba(0,0,0,0.9)]' 
          : 'text-gray-900 filter drop-shadow-[0_0_8px_rgba(255,255,255,0.7)]'
        }
        hover:animate-pulse
      `}
      style={{
        textShadow: piece.color === 'white' 
          ? '3px 3px 6px rgba(0,0,0,0.9), 0 0 15px rgba(255,255,255,0.4), 0 0 25px rgba(255,215,0,0.3)' 
          : '2px 2px 4px rgba(255,255,255,0.9), 0 0 12px rgba(0,0,0,0.4), 0 0 20px rgba(139,69,19,0.3)',
        filter: 'drop-shadow(0 6px 12px rgba(0,0,0,0.4))',
        background: piece.color === 'white' 
          ? 'linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,215,0,0.1))'
          : 'linear-gradient(145deg, rgba(0,0,0,0.1), rgba(139,69,19,0.1))',
        borderRadius: '50%',
        padding: '8px'
      }}
      draggable
      onDragStart={onDragStart}
      onClick={onClick}
    >
      {PIECE_SYMBOLS[piece.color][piece.type]}
    </div>
  );
}