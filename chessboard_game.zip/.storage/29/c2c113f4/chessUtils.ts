import { Board, ChessPiece, Position, PieceColor, PieceType } from './chessTypes';

export const PIECE_SYMBOLS: Record<PieceColor, Record<PieceType, string>> = {
  white: {
    king: '♔',
    queen: '♕',
    rook: '♖',
    bishop: '♗',
    knight: '♘',
    pawn: '♙'
  },
  black: {
    king: '♚',
    queen: '♛',
    rook: '♜',
    bishop: '♝',
    knight: '♞',
    pawn: '♟'
  }
};

export function createInitialBoard(): Board {
  const board: Board = Array(8).fill(null).map(() => Array(8).fill(null));
  
  // Place pawns
  for (let col = 0; col < 8; col++) {
    board[1][col] = { type: 'pawn', color: 'black', hasMoved: false };
    board[6][col] = { type: 'pawn', color: 'white', hasMoved: false };
  }
  
  // Place other pieces
  const pieceOrder: PieceType[] = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
  
  for (let col = 0; col < 8; col++) {
    board[0][col] = { type: pieceOrder[col], color: 'black', hasMoved: false };
    board[7][col] = { type: pieceOrder[col], color: 'white', hasMoved: false };
  }
  
  return board;
}

export function isValidPosition(pos: Position): boolean {
  return pos.row >= 0 && pos.row < 8 && pos.col >= 0 && pos.col < 8;
}

export function isSamePosition(pos1: Position, pos2: Position): boolean {
  return pos1.row === pos2.row && pos1.col === pos2.col;
}

export function getSquareColor(row: number, col: number): 'light' | 'dark' {
  return (row + col) % 2 === 0 ? 'light' : 'dark';
}

export function positionToAlgebraic(pos: Position): string {
  return String.fromCharCode(97 + pos.col) + (8 - pos.row);
}

export function copyBoard(board: Board): Board {
  return board.map(row => row.map(piece => piece ? { ...piece } : null));
}

export function createInitialGameState() {
  return {
    board: createInitialBoard(),
    currentPlayer: 'white' as PieceColor,
    selectedSquare: null,
    validMoves: [],
    gameStatus: 'playing' as const,
    moveHistory: [],
    canCastleKingside: { white: true, black: true },
    canCastleQueenside: { white: true, black: true },
    enPassantTarget: null
  };
}