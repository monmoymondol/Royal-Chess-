import { GameState } from '@/lib/chessTypes';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Crown, Sword, Shield, AlertTriangle } from 'lucide-react';

interface GameStatusProps {
  gameState: GameState;
  onNewGame: () => void;
}

export default function GameStatus({ gameState, onNewGame }: GameStatusProps) {
  const getStatusIcon = () => {
    switch (gameState.gameStatus) {
      case 'check':
        return <AlertTriangle className="w-6 h-6 text-red-500 animate-pulse" />;
      case 'checkmate':
        return <Crown className="w-6 h-6 text-red-600 animate-bounce" />;
      default:
        return gameState.currentPlayer === 'white' 
          ? <Shield className="w-6 h-6 text-blue-500" />
          : <Sword className="w-6 h-6 text-gray-700" />;
    }
  };

  const getStatusText = () => {
    switch (gameState.gameStatus) {
      case 'check':
        return `${gameState.currentPlayer === 'white' ? 'White' : 'Black'} King in Check!`;
      case 'checkmate':
        const winner = gameState.currentPlayer === 'white' ? 'Black' : 'White';
        return `Checkmate! ${winner} Wins!`;
      case 'stalemate':
        return 'Stalemate - Draw!';
      default:
        return `${gameState.currentPlayer === 'white' ? 'White' : 'Black'}'s Turn`;
    }
  };

  const getStatusColor = () => {
    switch (gameState.gameStatus) {
      case 'check':
        return 'bg-red-100 border-red-300 text-red-800';
      case 'checkmate':
        return 'bg-red-200 border-red-400 text-red-900';
      case 'stalemate':
        return 'bg-gray-100 border-gray-300 text-gray-800';
      default:
        return gameState.currentPlayer === 'white' 
          ? 'bg-blue-100 border-blue-300 text-blue-800'
          : 'bg-gray-100 border-gray-400 text-gray-800';
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-gradient-to-br from-amber-50 to-yellow-100 border-4 border-amber-300 shadow-2xl">
      <CardHeader className="text-center bg-gradient-to-r from-amber-600 to-yellow-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center justify-center gap-3 text-2xl font-bold tracking-wide">
          <Crown className="w-8 h-8 text-yellow-200" />
          Royal Chess
          <Crown className="w-8 h-8 text-yellow-200" />
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-6 space-y-6">
        {/* Current Status */}
        <div className={`p-4 rounded-xl border-2 transition-all duration-500 ${getStatusColor()}`}>
          <div className="flex items-center justify-center gap-3">
            {getStatusIcon()}
            <span className="text-xl font-bold tracking-wide">
              {getStatusText()}
            </span>
          </div>
        </div>

        {/* Game Statistics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-white rounded-lg border-2 border-amber-200 shadow-md">
            <div className="text-2xl font-bold text-amber-700">
              {gameState.moveHistory.length}
            </div>
            <div className="text-sm text-amber-600 font-medium">Moves</div>
          </div>
          
          <div className="text-center p-3 bg-white rounded-lg border-2 border-amber-200 shadow-md">
            <div className="text-2xl font-bold text-amber-700">
              {Math.floor(gameState.moveHistory.length / 2) + 1}
            </div>
            <div className="text-sm text-amber-600 font-medium">Turn</div>
          </div>
        </div>

        {/* Castling Status */}
        <div className="space-y-2">
          <h4 className="text-lg font-semibold text-amber-800 text-center">Castling Rights</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="text-center">
              <div className="text-sm font-medium text-gray-600 mb-1">White</div>
              <div className="flex justify-center gap-1">
                <Badge variant={gameState.canCastleKingside.white ? "default" : "secondary"} className="text-xs">
                  K-side
                </Badge>
                <Badge variant={gameState.canCastleQueenside.white ? "default" : "secondary"} className="text-xs">
                  Q-side
                </Badge>
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-gray-600 mb-1">Black</div>
              <div className="flex justify-center gap-1">
                <Badge variant={gameState.canCastleKingside.black ? "default" : "secondary"} className="text-xs">
                  K-side
                </Badge>
                <Badge variant={gameState.canCastleQueenside.black ? "default" : "secondary"} className="text-xs">
                  Q-side
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* New Game Button */}
        <Button 
          onClick={onNewGame}
          className="w-full bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 
                     text-white font-bold py-3 px-6 rounded-xl shadow-lg transform transition-all duration-300 
                     hover:scale-105 hover:shadow-xl border-2 border-amber-500"
        >
          <Crown className="w-5 h-5 mr-2" />
          New Royal Game
        </Button>
      </CardContent>
    </Card>
  );
}