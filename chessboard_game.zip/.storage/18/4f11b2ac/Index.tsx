import { useState } from 'react';
import { GameState } from '@/lib/chessTypes';
import { createInitialBoard } from '@/lib/chessUtils';
import ChessBoard from '@/components/ChessBoard';
import GameStatus from '@/components/GameStatus';

export default function Index() {
  const [gameState, setGameState] = useState<GameState>({
    board: createInitialBoard(),
    currentPlayer: 'white',
    selectedSquare: null,
    validMoves: [],
    gameStatus: 'playing',
    moveHistory: []
  });

  const handleReset = () => {
    setGameState({
      board: createInitialBoard(),
      currentPlayer: 'white',
      selectedSquare: null,
      validMoves: [],
      gameStatus: 'playing',
      moveHistory: []
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900 p-4">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-400 bg-clip-text text-transparent mb-4 drop-shadow-lg">
            ♔ Royal Chess ♛
          </h1>
          <p className="text-amber-200 text-xl font-medium">
            Experience chess in stunning 3D-styled gameplay
          </p>
          <div className="w-32 h-1 bg-gradient-to-r from-amber-400 to-yellow-400 mx-auto mt-4 rounded-full"></div>
        </div>
        
        <div className="flex flex-col xl:flex-row items-start justify-center gap-12">
          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-amber-600 to-yellow-600 rounded-3xl blur opacity-20"></div>
              <div className="relative">
                <ChessBoard 
                  gameState={gameState}
                  onGameStateChange={setGameState}
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-center xl:justify-start">
            <GameStatus
              currentPlayer={gameState.currentPlayer}
              gameStatus={gameState.gameStatus}
              onReset={handleReset}
            />
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <div className="bg-black/20 backdrop-blur-sm rounded-2xl p-6 max-w-4xl mx-auto border border-amber-500/20">
            <h3 className="text-2xl font-bold text-amber-300 mb-4">Game Features</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-amber-100">
              <div className="bg-amber-900/30 p-4 rounded-xl border border-amber-600/30">
                <div className="text-3xl mb-2">🎯</div>
                <div className="font-semibold">Smart Moves</div>
                <div className="text-sm opacity-80">Valid moves highlighted</div>
              </div>
              <div className="bg-amber-900/30 p-4 rounded-xl border border-amber-600/30">
                <div className="text-3xl mb-2">👑</div>
                <div className="font-semibold">Pawn Promotion</div>
                <div className="text-sm opacity-80">Choose your promotion piece</div>
              </div>
              <div className="bg-amber-900/30 p-4 rounded-xl border border-amber-600/30">
                <div className="text-3xl mb-2">🎨</div>
                <div className="font-semibold">3D Effects</div>
                <div className="text-sm opacity-80">Beautiful visual styling</div>
              </div>
              <div className="bg-amber-900/30 p-4 rounded-xl border border-amber-600/30">
                <div className="text-3xl mb-2">⚡</div>
                <div className="font-semibold">Drag & Drop</div>
                <div className="text-sm opacity-80">Smooth interactions</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}