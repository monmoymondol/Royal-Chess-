import { ChessPiece as ChessPieceType } from '@/lib/chessTypes';
import { PIECE_SYMBOLS } from '@/lib/chessUtils';

interface ChessPieceProps {
  piece: ChessPieceType;
  onDragStart?: (e: React.DragEvent) => void;
  onClick?: () => void;
  isDragging?: boolean;
}

export default function ChessPiece({ piece, onDragStart, onClick, isDragging }: ChessPieceProps) {
  return (
    <div
      className={`
        text-4xl cursor-pointer select-none transition-all duration-200
        hover:scale-110 active:scale-95
        ${isDragging ? 'opacity-50' : 'opacity-100'}
      `}
      draggable
      onDragStart={onDragStart}
      onClick={onClick}
    >
      {PIECE_SYMBOLS[piece.color][piece.type]}
    </div>
  );
}