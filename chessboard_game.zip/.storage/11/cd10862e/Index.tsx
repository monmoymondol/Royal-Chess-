import { useState } from 'react';
import { GameState } from '@/lib/chessTypes';
import { createInitialBoard } from '@/lib/chessUtils';
import ChessBoard from '@/components/ChessBoard';
import GameStatus from '@/components/GameStatus';

export default function Index() {
  const [gameState, setGameState] = useState<GameState>({
    board: createInitialBoard(),
    currentPlayer: 'white',
    selectedSquare: null,
    validMoves: [],
    gameStatus: 'playing',
    moveHistory: []
  });

  const handleReset = () => {
    setGameState({
      board: createInitialBoard(),
      currentPlayer: 'white',
      selectedSquare: null,
      validMoves: [],
      gameStatus: 'playing',
      moveHistory: []
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 p-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Chess Game</h1>
          <p className="text-gray-600">A fully functional chess game with drag & drop</p>
        </div>
        
        <div className="flex flex-col lg:flex-row items-start justify-center gap-8">
          <div className="flex justify-center">
            <ChessBoard 
              gameState={gameState}
              onGameStateChange={setGameState}
            />
          </div>
          
          <div className="flex justify-center lg:justify-start">
            <GameStatus
              currentPlayer={gameState.currentPlayer}
              gameStatus={gameState.gameStatus}
              onReset={handleReset}
            />
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>• Click a piece to select it, then click a highlighted square to move</p>
          <p>• You can also drag and drop pieces</p>
          <p>• Valid moves are highlighted in green</p>
        </div>
      </div>
    </div>
  );
}