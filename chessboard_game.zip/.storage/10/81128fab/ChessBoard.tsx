import { useState, useCallback } from 'react';
import { Board, Position, GameState, PieceColor } from '@/lib/chessTypes';
import { createInitialBoard, getSquareColor, isSamePosition } from '@/lib/chessUtils';
import { getValidMoves, isInCheck, isCheckmate, makeMove } from '@/lib/chessLogic';
import ChessPiece from './ChessPiece';

interface ChessBoardProps {
  gameState: GameState;
  onGameStateChange: (gameState: GameState) => void;
}

export default function ChessBoard({ gameState, onGameStateChange }: ChessBoardProps) {
  const [draggedPiece, setDraggedPiece] = useState<Position | null>(null);

  const handleSquareClick = useCallback((row: number, col: number) => {
    const clickedPos = { row, col };
    const piece = gameState.board[row][col];

    // If no square is selected
    if (!gameState.selectedSquare) {
      // Select square if it has a piece of the current player
      if (piece && piece.color === gameState.currentPlayer) {
        const validMoves = getValidMoves(gameState.board, clickedPos);
        onGameStateChange({
          ...gameState,
          selectedSquare: clickedPos,
          validMoves
        });
      }
      return;
    }

    // If clicking the same square, deselect
    if (isSamePosition(gameState.selectedSquare, clickedPos)) {
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
      return;
    }

    // If clicking another piece of the same color, select it
    if (piece && piece.color === gameState.currentPlayer) {
      const validMoves = getValidMoves(gameState.board, clickedPos);
      onGameStateChange({
        ...gameState,
        selectedSquare: clickedPos,
        validMoves
      });
      return;
    }

    // Check if the move is valid
    const isValidMove = gameState.validMoves.some(move => 
      isSamePosition(move, clickedPos)
    );

    if (isValidMove) {
      // Make the move
      const newBoard = makeMove(gameState.board, gameState.selectedSquare, clickedPos);
      const nextPlayer: PieceColor = gameState.currentPlayer === 'white' ? 'black' : 'white';
      
      // Check game status
      let newGameStatus: GameState['gameStatus'] = 'playing';
      if (isInCheck(newBoard, nextPlayer)) {
        newGameStatus = isCheckmate(newBoard, nextPlayer) ? 'checkmate' : 'check';
      }

      onGameStateChange({
        ...gameState,
        board: newBoard,
        currentPlayer: nextPlayer,
        selectedSquare: null,
        validMoves: [],
        gameStatus: newGameStatus
      });
    } else {
      // Invalid move, deselect
      onGameStateChange({
        ...gameState,
        selectedSquare: null,
        validMoves: []
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragStart = useCallback((row: number, col: number) => {
    const piece = gameState.board[row][col];
    if (piece && piece.color === gameState.currentPlayer) {
      setDraggedPiece({ row, col });
      const validMoves = getValidMoves(gameState.board, { row, col });
      onGameStateChange({
        ...gameState,
        selectedSquare: { row, col },
        validMoves
      });
    }
  }, [gameState, onGameStateChange]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, row: number, col: number) => {
    e.preventDefault();
    if (draggedPiece) {
      handleSquareClick(row, col);
      setDraggedPiece(null);
    }
  }, [draggedPiece, handleSquareClick]);

  const isSquareSelected = (row: number, col: number) => {
    return gameState.selectedSquare && 
           isSamePosition(gameState.selectedSquare, { row, col });
  };

  const isValidMoveSquare = (row: number, col: number) => {
    return gameState.validMoves.some(move => 
      isSamePosition(move, { row, col })
    );
  };

  return (
    <div className="inline-block border-4 border-gray-800 rounded-lg shadow-2xl">
      {gameState.board.map((row, rowIndex) => (
        <div key={rowIndex} className="flex">
          {row.map((piece, colIndex) => {
            const squareColor = getSquareColor(rowIndex, colIndex);
            const isSelected = isSquareSelected(rowIndex, colIndex);
            const isValidMove = isValidMoveSquare(rowIndex, colIndex);
            const isDragging = draggedPiece && 
                             isSamePosition(draggedPiece, { row: rowIndex, col: colIndex });

            return (
              <div
                key={`${rowIndex}-${colIndex}`}
                className={`
                  w-16 h-16 flex items-center justify-center relative cursor-pointer
                  transition-all duration-200
                  ${squareColor === 'light' ? 'bg-amber-100' : 'bg-amber-800'}
                  ${isSelected ? 'ring-4 ring-blue-500' : ''}
                  ${isValidMove ? 'ring-2 ring-green-400' : ''}
                  hover:brightness-110
                `}
                onClick={() => handleSquareClick(rowIndex, colIndex)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, rowIndex, colIndex)}
              >
                {piece && (
                  <ChessPiece
                    piece={piece}
                    onDragStart={() => handleDragStart(rowIndex, colIndex)}
                    isDragging={isDragging}
                  />
                )}
                {isValidMove && !piece && (
                  <div className="w-4 h-4 bg-green-400 rounded-full opacity-70" />
                )}
                {isValidMove && piece && (
                  <div className="absolute inset-0 border-4 border-green-400 rounded-full opacity-70" />
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}