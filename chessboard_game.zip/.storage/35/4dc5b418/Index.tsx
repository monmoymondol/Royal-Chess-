import { useState } from 'react';
import ChessBoard from '@/components/ChessBoard';
import GameStatus from '@/components/GameStatus';
import { createInitialGameState } from '@/lib/chessUtils';

export default function ChessGame() {
  const [gameState, setGameState] = useState(createInitialGameState());

  const handleNewGame = () => {
    setGameState(createInitialGameState());
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-900 via-yellow-800 to-amber-700 p-8">
      {/* Royal Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-32 h-32 bg-yellow-400 rounded-full blur-3xl"></div>
        <div className="absolute top-40 right-32 w-48 h-48 bg-amber-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-32 left-40 w-40 h-40 bg-yellow-300 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-36 h-36 bg-amber-300 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Royal Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-yellow-200 via-yellow-100 to-amber-200 
                         bg-clip-text text-transparent drop-shadow-2xl mb-4 tracking-wider">
            ♔ ROYAL CHESS MASTER ♛
          </h1>
          <p className="text-xl text-amber-100 font-medium tracking-wide drop-shadow-lg">
            Experience the Ultimate Chess Battle with Full Rules & Castling
          </p>
          <div className="mt-4 flex justify-center">
            <div className="h-1 w-32 bg-gradient-to-r from-transparent via-yellow-400 to-transparent rounded-full"></div>
          </div>
        </div>

        {/* Game Layout */}
        <div className="flex flex-col lg:flex-row items-start justify-center gap-12">
          {/* Chess Board */}
          <div className="flex-shrink-0">
            <ChessBoard 
              gameState={gameState} 
              onGameStateChange={setGameState} 
            />
          </div>

          {/* Game Status Panel */}
          <div className="flex-shrink-0 w-full lg:w-auto">
            <GameStatus 
              gameState={gameState} 
              onNewGame={handleNewGame} 
            />
            
            {/* Move History */}
            {gameState.moveHistory.length > 0 && (
              <div className="mt-8 bg-gradient-to-br from-amber-50 to-yellow-100 border-4 border-amber-300 
                              rounded-2xl shadow-2xl p-6 max-w-md">
                <h3 className="text-2xl font-bold text-amber-800 text-center mb-4 flex items-center justify-center gap-2">
                  📜 Move History
                </h3>
                <div className="max-h-64 overflow-y-auto space-y-2 bg-white rounded-lg p-4 border-2 border-amber-200">
                  {gameState.moveHistory.map((move, index) => (
                    <div key={index} className="flex justify-between items-center p-2 rounded bg-amber-50 
                                                hover:bg-amber-100 transition-colors border border-amber-200">
                      <span className="font-medium text-amber-700">
                        {Math.floor(index / 2) + 1}.{index % 2 === 0 ? '' : '..'}
                      </span>
                      <span className="text-amber-800 font-mono">
                        {move.piece.type === 'king' && Math.abs(move.to.col - move.from.col) === 2
                          ? move.to.col === 6 ? 'O-O' : 'O-O-O'
                          : `${move.piece.type !== 'pawn' ? move.piece.type.charAt(0).toUpperCase() : ''}${String.fromCharCode(97 + move.to.col)}${8 - move.to.row}`
                        }
                      </span>
                      <span className="text-xs text-amber-600">
                        {move.isCastling ? '🏰' : move.capturedPiece ? '⚔️' : ''}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Royal Footer */}
        <div className="text-center mt-16 text-amber-200">
          <p className="text-lg font-medium tracking-wide drop-shadow-lg">
            ✨ Complete Chess Rules • Castling • En Passant • Pawn Promotion ✨
          </p>
        </div>
      </div>
    </div>
  );
}