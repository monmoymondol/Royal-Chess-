import { Board, ChessPiece, Position, PieceColor, Move } from './chessTypes';
import { isValidPosition, copyBoard, isSamePosition } from './chessUtils';

export function getValidMoves(board: Board, from: Position): Position[] {
  const piece = board[from.row][from.col];
  if (!piece) return [];

  const moves: Position[] = [];
  
  switch (piece.type) {
    case 'pawn':
      moves.push(...getPawnMoves(board, from, piece.color));
      break;
    case 'rook':
      moves.push(...getRookMoves(board, from, piece.color));
      break;
    case 'bishop':
      moves.push(...getBishopMoves(board, from, piece.color));
      break;
    case 'queen':
      moves.push(...getQueenMoves(board, from, piece.color));
      break;
    case 'king':
      moves.push(...getKingMoves(board, from, piece.color));
      break;
    case 'knight':
      moves.push(...getKnightMoves(board, from, piece.color));
      break;
  }

  // Filter out moves that would put own king in check
  return moves.filter(to => !wouldBeInCheck(board, from, to, piece.color));
}

function getPawnMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const direction = color === 'white' ? -1 : 1;
  const startRow = color === 'white' ? 6 : 1;

  // Forward move
  const oneStep = { row: from.row + direction, col: from.col };
  if (isValidPosition(oneStep) && !board[oneStep.row][oneStep.col]) {
    moves.push(oneStep);
    
    // Two steps from starting position
    if (from.row === startRow) {
      const twoSteps = { row: from.row + 2 * direction, col: from.col };
      if (isValidPosition(twoSteps) && !board[twoSteps.row][twoSteps.col]) {
        moves.push(twoSteps);
      }
    }
  }

  // Diagonal captures
  for (const colOffset of [-1, 1]) {
    const capturePos = { row: from.row + direction, col: from.col + colOffset };
    if (isValidPosition(capturePos)) {
      const targetPiece = board[capturePos.row][capturePos.col];
      if (targetPiece && targetPiece.color !== color) {
        moves.push(capturePos);
      }
    }
  }

  return moves;
}

function getRookMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const directions = [[0, 1], [0, -1], [1, 0], [-1, 0]];

  for (const [dRow, dCol] of directions) {
    for (let i = 1; i < 8; i++) {
      const pos = { row: from.row + i * dRow, col: from.col + i * dCol };
      if (!isValidPosition(pos)) break;

      const piece = board[pos.row][pos.col];
      if (!piece) {
        moves.push(pos);
      } else {
        if (piece.color !== color) {
          moves.push(pos);
        }
        break;
      }
    }
  }

  return moves;
}

function getBishopMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const directions = [[1, 1], [1, -1], [-1, 1], [-1, -1]];

  for (const [dRow, dCol] of directions) {
    for (let i = 1; i < 8; i++) {
      const pos = { row: from.row + i * dRow, col: from.col + i * dCol };
      if (!isValidPosition(pos)) break;

      const piece = board[pos.row][pos.col];
      if (!piece) {
        moves.push(pos);
      } else {
        if (piece.color !== color) {
          moves.push(pos);
        }
        break;
      }
    }
  }

  return moves;
}

function getQueenMoves(board: Board, from: Position, color: PieceColor): Position[] {
  return [...getRookMoves(board, from, color), ...getBishopMoves(board, from, color)];
}

function getKingMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const directions = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1],  [1, 0],  [1, 1]
  ];

  for (const [dRow, dCol] of directions) {
    const pos = { row: from.row + dRow, col: from.col + dCol };
    if (isValidPosition(pos)) {
      const piece = board[pos.row][pos.col];
      if (!piece || piece.color !== color) {
        moves.push(pos);
      }
    }
  }

  return moves;
}

function getKnightMoves(board: Board, from: Position, color: PieceColor): Position[] {
  const moves: Position[] = [];
  const knightMoves = [
    [-2, -1], [-2, 1], [-1, -2], [-1, 2],
    [1, -2], [1, 2], [2, -1], [2, 1]
  ];

  for (const [dRow, dCol] of knightMoves) {
    const pos = { row: from.row + dRow, col: from.col + dCol };
    if (isValidPosition(pos)) {
      const piece = board[pos.row][pos.col];
      if (!piece || piece.color !== color) {
        moves.push(pos);
      }
    }
  }

  return moves;
}

function findKing(board: Board, color: PieceColor): Position | null {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.type === 'king' && piece.color === color) {
        return { row, col };
      }
    }
  }
  return null;
}

function isSquareAttacked(board: Board, pos: Position, byColor: PieceColor): boolean {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === byColor) {
        const moves = getValidMovesWithoutCheckValidation(board, { row, col });
        if (moves.some(move => isSamePosition(move, pos))) {
          return true;
        }
      }
    }
  }
  return false;
}

function getValidMovesWithoutCheckValidation(board: Board, from: Position): Position[] {
  const piece = board[from.row][from.col];
  if (!piece) return [];

  switch (piece.type) {
    case 'pawn':
      return getPawnMoves(board, from, piece.color);
    case 'rook':
      return getRookMoves(board, from, piece.color);
    case 'bishop':
      return getBishopMoves(board, from, piece.color);
    case 'queen':
      return getQueenMoves(board, from, piece.color);
    case 'king':
      return getKingMoves(board, from, piece.color);
    case 'knight':
      return getKnightMoves(board, from, piece.color);
    default:
      return [];
  }
}

function wouldBeInCheck(board: Board, from: Position, to: Position, color: PieceColor): boolean {
  const newBoard = copyBoard(board);
  newBoard[to.row][to.col] = newBoard[from.row][from.col];
  newBoard[from.row][from.col] = null;

  const kingPos = findKing(newBoard, color);
  if (!kingPos) return false;

  return isSquareAttacked(newBoard, kingPos, color === 'white' ? 'black' : 'white');
}

export function isInCheck(board: Board, color: PieceColor): boolean {
  const kingPos = findKing(board, color);
  if (!kingPos) return false;

  return isSquareAttacked(board, kingPos, color === 'white' ? 'black' : 'white');
}

export function isCheckmate(board: Board, color: PieceColor): boolean {
  if (!isInCheck(board, color)) return false;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === color) {
        const moves = getValidMoves(board, { row, col });
        if (moves.length > 0) return false;
      }
    }
  }

  return true;
}

export function makeMove(board: Board, from: Position, to: Position): Board {
  const newBoard = copyBoard(board);
  newBoard[to.row][to.col] = newBoard[from.row][from.col];
  newBoard[from.row][from.col] = null;
  return newBoard;
}