import { ChessPiece as ChessPieceType } from '@/lib/chessTypes';
import { PIECE_SYMBOLS } from '@/lib/chessUtils';

interface ChessPieceProps {
  piece: ChessPieceType;
  onDragStart?: (e: React.DragEvent) => void;
  onClick?: () => void;
  isDragging?: boolean;
}

export default function ChessPiece({ piece, onDragStart, onClick, isDragging }: ChessPieceProps) {
  return (
    <div
      className={`
        text-5xl cursor-pointer select-none transition-all duration-300
        hover:scale-125 active:scale-95 hover:rotate-3
        ${isDragging ? 'opacity-50 scale-110' : 'opacity-100'}
        drop-shadow-lg hover:drop-shadow-2xl
        transform-gpu
        ${piece.color === 'white' 
          ? 'text-white filter drop-shadow-[0_0_8px_rgba(0,0,0,0.8)]' 
          : 'text-gray-900 filter drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]'
        }
      `}
      style={{
        textShadow: piece.color === 'white' 
          ? '2px 2px 4px rgba(0,0,0,0.8), 0 0 10px rgba(255,255,255,0.3)' 
          : '1px 1px 2px rgba(255,255,255,0.8), 0 0 8px rgba(0,0,0,0.3)',
        filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))'
      }}
      draggable
      onDragStart={onDragStart}
      onClick={onClick}
    >
      {PIECE_SYMBOLS[piece.color][piece.type]}
    </div>
  );
}